﻿jQuery(function ($) {
    $.timepickerLocalization = {
        hourText: 'Годину',
        minuteText: 'хвилина'
    };
});
