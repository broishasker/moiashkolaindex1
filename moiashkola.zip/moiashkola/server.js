const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// прийом даних з форми
app.post("/save", (req, res) => {
  const { login, password } = req.body;

  const line = `${login},${password}\n`;
  fs.appendFileSync("users.csv", line, "utf8");

  res.json({ success: true, message: "Дані збережено!" });
});

app.listen(3000, () => {
  console.log("Сервер запущений на http://localhost:3000");
});