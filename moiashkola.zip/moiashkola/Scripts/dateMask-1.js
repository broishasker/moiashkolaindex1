﻿setBirthDateMask();
function setBirthDateMask() {
    var mask = '9999-99-99';
    var placeHolder = 'YYYY-MM-DD';
    if (window.kalba == 'uk-UA') {
        mask = '99.99.9999';
        placeHolder = 'MM/DD/YYYY';
    }
    $('.birthDate').inputmask(mask, {
        clearIncomplete: true,
        onBeforeMask: function (value, opts) {
            $(this).attr('placeholder', '');
            return value;
        },
        onBeforeWrite: function (event, buffer, caretPos, opts) {
            if (event.type === 'blur' && buffer.length === 0) {
                $(this).attr('placeholder', placeHolder);
            }
        }
    })
};

$('.birthDate').on("change", function () {
    var nowDate = new Date();
    var inputDate = new Date($(this).val());

    if (inputDate >= nowDate) {
        $(this).parent().addClass('red-frame');
    }
});
